import React from "react";

export default function BlurImage({ src, alt, width, height }) {
  const [loaded, setLoaded] = React.useState(false);
  return (
    <div className={`blur-load ${loaded ? "image-loaded" : ""}`} style={{ width, height }}>
      <img src={src} alt={alt} onLoad={() => setLoaded(true)} loading="lazy" />
    </div>
  );
}
