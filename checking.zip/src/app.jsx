import React from "react";
import { me } from "./data";
import { FaGithub, FaLinkedin, FaEnvelope, FaDownload, FaMapMarkerAlt } from "react-icons/fa";
import Reveal from "./components/Reveal";
import BlurImage from "./components/BlurImage";

const Pill = ({ children }) => <span className="pill">{children}</span>;
const Section = ({ id, title, children }) => (
  <section id={id} aria-labelledby={`${id}-title`} className="section">
    <div className="container">
      <h2 id={`${id}-title`} className="h2">{title}</h2>
      {children}
    </div>
  </section>
);

export default function App() {
  return (
    <>
      <header className="header">
        <div className="container nav">
          <a className="brand" href="#top">{me.name}</a>
          <nav className="links" aria-label="Primary">
            <a href="#projects">Projects</a>
            <a href="#experience">Experience</a>
            <a href="#tech">Tech</a>
            <a href="#education">Education</a>
            <a href={me.links.resume} target="_blank" rel="noopener" className="btn small">
              <FaDownload aria-hidden /> Resume
            </a>
          </nav>
        </div>
      </header>

      <main id="top">
        <section className="hero">
          <div className="container heroInner">
            <Reveal><Pill>{me.available}</Pill></Reveal>
            <Reveal delay={0.08}>
              <h1 className="h1">Hi, I’m <span className="grad">{me.name}</span> — {me.title}.</h1>
            </Reveal>
            <Reveal delay={0.16}><p className="lead">{me.blurb}</p></Reveal>
            <Reveal delay={0.2}>
              <p className="muted">
                <FaMapMarkerAlt aria-hidden /> {me.location} ·{" "}
                <a href={`mailto:${me.email}`} className="link"><FaEnvelope aria-hidden /> {me.email}</a>
              </p>
            </Reveal>
            <Reveal delay={0.28}>
              <div className="social">
                <a href={me.links.github} target="_blank" rel="noopener" aria-label="GitHub"><FaGithub /></a>
                <a href={me.links.linkedin} target="_blank" rel="noopener" aria-label="LinkedIn"><FaLinkedin /></a>
                <a href={me.links.resume} target="_blank" rel="noopener" className="btn primary"><FaDownload aria-hidden /> Download Résumé</a>
              </div>
            </Reveal>
          </div>
        </section>

        <Section id="tech" title="Tech stack">
          <div className="grid three">
            {Object.entries(me.tech).map(([group, items]) => (
              <Reveal key={group}>
                <article className="card">
                  <h3 className="h3">{group}</h3>
                  <div className="chips">{items.map(s => <span key={s} className="chip">{s}</span>)}</div>
                </article>
              </Reveal>
            ))}
          </div>
        </Section>

        <Section id="projects" title="Featured projects">
          <div className="grid two">
            {me.projects.map((p) => (
              <Reveal key={p.title}>
                <article className="proj">
                  <div className="projMedia">
                    <BlurImage src={p.image} alt={p.title} width="100%" height="240px" />
                  </div>
                  <div className="projBody">
                    <header className="projHead">
                      <h3 className="h3">{p.title}</h3>
                      <span className="muted">{p.period}</span>
                    </header>
                    <div className="chips">{p.stack.map(s => <span className="chip" key={s}>{s}</span>)}</div>
                    <ul className="list">
                      {p.bullets.map((b, i) => <li key={i}>{b}</li>)}
                    </ul>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </Section>

        <Section id="experience" title="Experience">
          <div className="timeline">
            {me.experience.map((xp) => (
              <Reveal key={xp.company}>
                <article className="card">
                  <header className="cardHead">
                    <h3 className="h3">{xp.role} — {xp.company}</h3>
                    <span className="muted">{xp.period}</span>
                  </header>
                  <ul className="list">
                    {xp.bullets.map((b, i) => <li key={i}>{b}</li>)}
                  </ul>
                </article>
              </Reveal>
            ))}
          </div>
        </Section>

        <Section id="education" title="Education">
          <div className="grid two">
            {me.education.map((ed) => (
              <Reveal key={ed.school}>
                <article className="card">
                  <header className="cardHead">
                    <h3 className="h3">{ed.school}</h3>
                    <span className="muted">{ed.period}</span>
                  </header>
                  <p className="strong">{ed.degree}</p>
                  <details className="details">
                    <summary>Relevant coursework</summary>
                    <div className="chips">
                      {ed.coursework.map(c => <span className="chip" key={c}>{c}</span>)}
                    </div>
                  </details>
                </article>
              </Reveal>
            ))}
          </div>
        </Section>

        <Section id="extras" title="Publications & Certifications">
          <div className="grid two">
            <Reveal>
              <article className="card">
                <h3 className="h3">Publications</h3>
                <ul className="list tight">{me.publications.map((t, i) => <li key={i}>{t}</li>)}</ul>
              </article>
            </Reveal>
            <Reveal delay={0.06}>
              <article className="card">
                <h3 className="h3">Certifications</h3>
                <ul className="list tight">{me.certifications.map((t, i) => <li key={i}>{t}</li>)}</ul>
              </article>
            </Reveal>
          </div>
        </Section>
      </main>

      <footer className="footer" role="contentinfo">
        <div className="container footInner">
          <small>© {new Date().getFullYear()} {me.name}. Last updated {new Date().toLocaleDateString()}.</small>
        </div>
      </footer>
    </>
  );
}
