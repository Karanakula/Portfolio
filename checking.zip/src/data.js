export const me = {
  name: "SAI KARAN AKULA",
  title: "Software Engineer",
  blurb: "Full-stack + ML, focused on clear UX, performance, and real impact. Open to Summer 2026 internships in SWE/ML.",
  available: "Available for Summer 2026 internships",
  location: "San Jose, CA",
  email: "akula.work01@gmail.com",
  phone: "(408) 590-7372",
  links: {
    github: "https://github.com/Karanakula",
    linkedin: "https://www.linkedin.com/in/sai-karan-akula-6534a4268/",
    resume: "/resume.pdf"
  },
  tech: {
    "Languages": ["Java", "JavaScript", "C", "Python"],
    "Web & Backend": ["React", "Angular", "Node.js", "Express.js", "Flask", "HTML5", "CSS", "Bootstrap"],
    "Tools": ["GitHub", "Postman", "Figma"]
  },
  projects: [
    {
      title: "Potato Leaf Disease Detector",
      period: "Jan 2025 – Apr 2025",
      stack: ["Flask", "Deep Learning", "MongoDB", "Node.js"],
      bullets: [
        "Web app for uploading leaf images and returning disease predictions.",
        "Model pipeline with CNN + classical ML; responsive dashboard + history."
      ],
      image: "/images/proj1.jpg"
    },
    {
      title: "Pneumonia Detection via Chest X-rays",
      period: "Aug 2024 – Dec 2024",
      stack: ["TensorFlow", "ResNet50", "MobileNetV2", "VGG16"],
      bullets: [
        "Pretrained CNN feature extraction and multi-model evaluation.",
        "Metrics: precision, recall, F1, confusion matrix; clean experiment logs."
      ],
      image: "/images/proj2.jpg"
    }
  ],
  experience: [
    {
      role: "Technical Head",
      company: "VITMAS",
      period: "Jan 2022 – Dec 2024",
      bullets: [
        "Led a cross-functional team building MERN tools used across student events.",
        "Centralized portal for registrations, email automation, and analytics.",
        "JWT auth and responsive UI/UX."
      ]
    },
    {
      role: "R&D Intern",
      company: "NIT Warangal",
      period: "Nov 2023 – Dec 2023",
      bullets: [
        "Optimized image processing pipelines (LBP, OpenCV, NumPy).",
        "Prototyped CNN models with transfer learning; automated evaluation."
      ]
    }
  ],
  education: [
    {
      school: "San Jose State University",
      degree: "M.S., Software Engineering",
      period: "Aug 2025 – May 2027",
      coursework: [
        "Distributed Systems",
        "Cloud Technologies",
        "Enterprise Software Platforms",
        "Software Architecture",
        "Data Structures & Algorithms"
      ]
    },
    {
      school: "Vellore Institute of Technology",
      degree: "B.Tech, Information Technology • GPA 3.47",
      period: "Aug 2021 – May 2025",
      coursework: [
        "Database Systems",
        "Computer Networks",
        "Operating Systems",
        "Machine Learning",
        "Blockchain Technology",
        "Artificial Intelligence"
      ]
    }
  ],
  publications: [
    "Optimizing Image Steganography: Comparative Pre-Processing + Hybrid U-Encoder (ICIICS 2024)."
  ],
  certifications: [
    "AWS Cloud Foundations — Coursera (2024)",
    "Data Science & Hadoop Training — VIT (2023)"
  ]
};
